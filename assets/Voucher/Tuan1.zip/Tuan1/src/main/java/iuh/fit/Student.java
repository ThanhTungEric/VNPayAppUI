package iuh.fit;

public class Student {
	private int Id;
	private String firstname;
	private String lastname;
	private String emailname;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return emailname;
	}
	public void setEmail(String emailname) {
		this.emailname = emailname;
	}
	
	public Student(int id, String firstname, String lastname, String emailname) {
		
		Id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.emailname = emailname;
	}
	public Student( String firstname, String lastname, String emailname) {
	
		this.firstname = firstname;
		this.lastname = lastname;
		this.emailname = emailname;
	}
	
}
