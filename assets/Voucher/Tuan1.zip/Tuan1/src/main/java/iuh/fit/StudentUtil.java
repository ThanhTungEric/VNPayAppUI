package iuh.fit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;



public class StudentUtil {
	private DataSource dataSource;

	public StudentUtil(DataSource theDataSource) {
		dataSource = theDataSource;
	}
	
public List<Student> getStudents() throws Exception {		
	List<Student> students = new ArrayList<>();		
	Connection myConn = null;
	Statement myStmt = null;
	ResultSet myRs = null;		
	try {
		// lấy a connection
		myConn = dataSource.getConnection();			
		// tạo câu  sql 
		String sql = "select * from Student";			
		myStmt = myConn.createStatement();			
		// thực thi query
		myRs = myStmt.executeQuery(sql);			
		// Xử lý kết quả của câu truy vấn
		while (myRs.next()) {				
			// đọc kết quả theo dòng
			int id = myRs.getInt("ID");
			String firstName = myRs.getString("FirstName");
			String lastName = myRs.getString("LastName");
			String email = myRs.getString("Email");				
			// tạo đối tượng Sinh vien
			Student tempStudent = new Student(id, firstName, lastName, email);				
			// Thêm vào list students
			students.add(tempStudent);}			
		return students;}
	  finally {
		// đóng connection
		close(myConn, myStmt, myRs);}		
}
	private void close(Connection myConn, Statement myStmt, ResultSet myRs) {
		try {
			if (myRs != null) {
				myRs.close(); }			
			if (myStmt != null) {
				myStmt.close();	}			
			if (myConn != null) {
				myConn.close();   
				// doesn't really close it ... just puts back in connection pool
			}
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
	}

	public void addStudent(Student theStudent) throws Exception {
		Connection myConn = null;
		PreparedStatement myStmt = null;		
		try {
			// lấy a connection
			myConn = dataSource.getConnection();			
			// tạo câu  sql 
			String sql = "insert into Student "
					   + "(FirstName, LastName, Email) "
					   + "values (?, ?, ?)";			
			myStmt = myConn.prepareStatement(sql);			
			// thiết lập value cho đối tượng Sinhvien
			myStmt.setString(1, theStudent.getFirstname());
			myStmt.setString(2, theStudent.getLastname());
			myStmt.setString(3, theStudent.getEmail());			
			// execute sql insert
			myStmt.execute();
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);
		}
	}

	public Student getStudent(String theStudentId) throws Exception {
		Student theStudent = null;	
		Connection myConn = null;
		PreparedStatement myStmt = null;
		ResultSet myRs = null;
		int studentId;		
		try {
			// convert student id to int
			studentId = Integer.parseInt(theStudentId);			
			// get connection to database
			myConn = dataSource.getConnection();			
			// create sql to get selected student
			String sql = "select * from Student where ID=?";			
			// create prepared statement
			myStmt = myConn.prepareStatement(sql);			
			// set params
			myStmt.setInt(1, studentId);			
			// execute statement
			myRs = myStmt.executeQuery();			
			// retrieve data from result set row
			if (myRs.next()) {
				String firstName = myRs.getString("FirstName");
				String lastName = myRs.getString("LastName");
				String email = myRs.getString("Email");				
				// use the studentId during construction
				theStudent = new Student(studentId, firstName, lastName, email);
			}
			else {
				throw new Exception("Could not find student id: " + studentId);	}							
			return theStudent;
		}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, myRs);}
	}

	public void updateStudent(Student theStudent) throws Exception {		
		Connection myConn = null;
		PreparedStatement myStmt = null;
		try {
			// get db connection
			myConn = dataSource.getConnection();			
			// create SQL update statement
			String sql = "update Student "
						+ "set FirstName=?, LastName=?, Email=? "
						+ "where id=?";			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);			
			// set params
			myStmt.setString(1, theStudent.getFirstname());
			myStmt.setString(2, theStudent.getLastname());
			myStmt.setString(3, theStudent.getEmail());
			myStmt.setInt(4, theStudent.getId());			
			// execute SQL statement
			myStmt.execute();}
		finally {
			// clean up JDBC objects
			close(myConn, myStmt, null);}
	}

	public void deleteStudent(String theStudentId) throws Exception {
		Connection myConn = null;
		PreparedStatement myStmt = null;		
		try {
			// convert student id to int
			int studentId = Integer.parseInt(theStudentId);			
			// get connection to database
			myConn = dataSource.getConnection();			
			// create sql to delete student
			String sql = "delete from Student where id=?";			
			// prepare statement
			myStmt = myConn.prepareStatement(sql);			
			// set params
			myStmt.setInt(1, studentId);			
			// execute sql statement
			myStmt.execute();}
		finally {
			// clean up JDBC code
			close(myConn, myStmt, null);}	
	} 
	
	

}
